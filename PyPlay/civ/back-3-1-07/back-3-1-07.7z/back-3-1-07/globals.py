

class faction_info:
    def __init__(self, num, colors):
        self.num_factions = num
        self.colors = colors
